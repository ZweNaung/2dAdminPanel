package com.example.twodamin.util

object Constants {
    const val BASE_URL =  "http://mmsub.asia:8080/api/"
}